"""Prepare the locked YouTube downloader runtime in the application cache."""

import argparse
import contextlib
import errno
import hashlib
import json
from pathlib import Path, PurePosixPath
import platform
import runpy
import shutil
import stat
import sys
import tempfile
import time
from urllib.parse import urlsplit
from urllib.request import Request, urlopen
import zipfile


HERE = Path(__file__).resolve().parent
LOCK = HERE / "wheels.lock.json"
DOWNLOAD_HOST = "files.pythonhosted.org"


def platform_name():
    machine = platform.machine().lower()
    if sys.platform == "darwin" and machine == "arm64":
        return "macos-arm64"
    if sys.platform == "win32" and machine in ("amd64", "x86_64"):
        return "windows-amd64"
    raise RuntimeError("YouTube fallback requires native Apple Silicon or Windows x64 Python")


@contextlib.contextmanager
def runtime_lock(path):
    # Keep the lock file in place. The OS releases the advisory lock even if
    # the parent application stops a download while dependencies are staged.
    with path.open("a+b") as handle:
        if sys.platform == "win32":
            import msvcrt

            def acquire():
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)

            def release():
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl

            def acquire():
                fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)

            def release():
                fcntl.flock(handle, fcntl.LOCK_UN)

        deadline = time.monotonic() + 300
        while True:
            try:
                acquire()
                break
            except OSError as err:
                if err.errno not in (errno.EACCES, errno.EAGAIN, errno.EDEADLK):
                    raise
                if time.monotonic() >= deadline:
                    raise RuntimeError("timed out waiting for YouTube fallback setup") from err
                time.sleep(0.2)
        try:
            yield
        finally:
            release()


def trusted_wheel_url(url):
    parsed = urlsplit(url)
    return parsed.scheme == "https" and parsed.netloc == DOWNLOAD_HOST


def download_wheel(wheel, archive):
    url = wheel["url"]
    if not trusted_wheel_url(url):
        raise RuntimeError("untrusted wheel download host")
    request = Request(url, headers={"User-Agent": "RelayStudio YouTube fallback"})
    digest = hashlib.sha256()
    written = 0
    with urlopen(request, timeout=30) as response, archive.open("wb") as target:
        if not trusted_wheel_url(response.geturl()):
            raise RuntimeError("wheel download redirected to an untrusted host")
        while chunk := response.read(1024 * 1024):
            written += len(chunk)
            if written > wheel["size"]:
                raise RuntimeError("wheel exceeds the locked size")
            digest.update(chunk)
            target.write(chunk)
    if written != wheel["size"] or digest.hexdigest() != wheel["sha256"]:
        raise RuntimeError("wheel does not match the locked size and checksum")


def unpack_wheel(archive, destination):
    with zipfile.ZipFile(archive) as wheel:
        for entry in wheel.infolist():
            path = PurePosixPath(entry.filename)
            if path.is_absolute() or ".." in path.parts or "\\" in entry.filename or ":" in entry.filename:
                raise RuntimeError("wheel contains an invalid path")
            parts = path.parts
            mode = entry.external_attr >> 16
            if not parts or entry.is_dir() or stat.S_ISLNK(mode):
                continue
            if parts[0].endswith(".data"):
                if len(parts) < 3 or parts[1] not in ("purelib", "platlib"):
                    continue
                parts = parts[2:]
            target = destination.joinpath(*parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            with wheel.open(entry) as source, target.open("wb") as out:
                shutil.copyfileobj(source, out)
            if mode & 0o111:
                target.chmod(0o755)


def prepare_runtime(cache):
    # Every stored wheel is universal or a Node sidecar for this platform.
    # The lock digest keeps updates from overwriting the runtime of an
    # in-flight download started by an older app version.
    if sys.version_info < (3, 10):
        raise RuntimeError("YouTube fallback requires Python 3.10 or later")
    target_platform = platform_name()
    data = LOCK.read_bytes()
    packages = json.loads(data)
    digest = hashlib.sha256(data).hexdigest()
    runtime = cache / (target_platform + "-" + digest[:24])
    cache.mkdir(mode=0o700, parents=True, exist_ok=True)
    marker = runtime / ".complete"
    if marker.is_file():
        return runtime
    with runtime_lock(cache / (runtime.name + ".lock")):
        if marker.is_file():
            return runtime
        with tempfile.TemporaryDirectory(prefix="prepare-", dir=cache) as name:
            staging = Path(name)
            dependencies = staging / "dependencies"
            dependencies.mkdir()
            archive = staging / "wheel.zip"
            for variants in packages.values():
                wheel = variants.get(target_platform) or variants["all"]
                download_wheel(wheel, archive)
                unpack_wheel(archive, dependencies)
            (dependencies / ".complete").write_text(digest, encoding="ascii")
            dependencies.rename(runtime)
    return runtime


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache-dir", type=Path, required=True)
    parser.add_argument("--prewarm", action="store_true")
    parser.add_argument("--video-id")
    parser.add_argument("--output")
    parser.add_argument("--ffmpeg")
    args = parser.parse_args()
    if not args.cache_dir.is_absolute():
        parser.error("--cache-dir must be absolute")
    if not args.prewarm and not all((args.video_id, args.output, args.ffmpeg)):
        parser.error("--video-id, --output and --ffmpeg are required")
    try:
        runtime = prepare_runtime(args.cache_dir)
    except (OSError, RuntimeError, ValueError, KeyError, zipfile.BadZipFile) as err:
        # The wheel sources are fixed public URLs. Report concise setup failures
        # without including transport or process diagnostic output.
        print(f"YouTube fallback runtime setup failed ({type(err).__name__}): {err}", file=sys.stderr)
        return 1
    if args.prewarm:
        return 0
    helper = HERE / "download.py"
    if not helper.is_file():
        helper = HERE.parent.parent / "internal/platformvideo/youtube_fallback/download.py"
    sys.path.insert(0, str(runtime))
    sys.argv = [str(helper), f"--video-id={args.video_id}", "--output", args.output, "--ffmpeg", args.ffmpeg]
    runpy.run_path(str(helper), run_name="__main__")
    return 0


if __name__ == "__main__":
    sys.exit(main())
