"""Download one public YouTube video into the caller's staging directory."""

import argparse
import logging
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
import tempfile
from urllib.error import HTTPError, URLError


PYTUBEFIX_VERSION = "11.2.1"
NETWORK_TIMEOUT_SECONDS = 20
VIDEO_ID = re.compile(r"[A-Za-z0-9_-]{11}")


class DownloadError(Exception):
    """An error whose message is safe to include in the download receipt."""


def video_rank(stream):
    resolution = re.fullmatch(r"(\d+)p", stream.resolution or "")
    return (int(resolution[1]) if resolution else 0, stream.fps or 0)


def audio_rank(stream):
    bitrate = re.fullmatch(r"(\d+)kbps", stream.abr or "")
    return int(bitrate[1]) if bitrate else 0


def select_streams(streams):
    video_streams = []
    combined_streams = []
    audio_streams = []
    for stream in streams:
        if stream.subtype != "mp4":
            continue
        h264 = (stream.video_codec or "").startswith(("avc1", "avc3"))
        aac = (stream.audio_codec or "").startswith("mp4a")
        if stream.includes_video_track:
            if h264 and not stream.includes_audio_track:
                video_streams.append(stream)
            elif h264 and aac:
                combined_streams.append(stream)
        elif stream.includes_audio_track and aac:
            audio_streams.append(stream)

    combined = max(combined_streams, key=video_rank, default=None)
    video = max(video_streams, key=video_rank, default=None)
    audio = max(audio_streams, key=audio_rank, default=None)
    if video is not None and audio is not None and (
        combined is None or video_rank(video) > video_rank(combined)
    ):
        return video, audio
    if combined is not None:
        return combined, None
    raise DownloadError("YouTube 未提供可下载的 H.264 视频和 AAC 音轨")


def download_stream(stream, work_dir, filename):
    result = stream.download(
        output_path=str(work_dir),
        filename=filename,
        skip_existing=False,
        timeout=NETWORK_TIMEOUT_SECONDS,
        max_retries=1,
    )
    path = work_dir / filename
    if result is None or not path.is_file():
        raise DownloadError("YouTube 音视频流下载不完整")
    size = path.stat().st_size
    # pytubefix may return a path when a later HTTP range returned 404.
    # SABR is reassembled by pytubefix rather than copied byte for byte.
    if size == 0 or (not stream.is_sabr and size != stream.filesize):
        raise DownloadError("YouTube 音视频流下载不完整")
    return path


def merge_streams(ffmpeg, video, audio, output):
    input_args = ["-i", str(video)]
    if audio is not None:
        input_args.extend(["-i", str(audio)])
    audio_map = "1:a:0" if audio is not None else "0:a:0"
    try:
        subprocess.run(
            [
                ffmpeg, "-nostdin", "-hide_banner", "-loglevel", "error", "-xerror",
                "-abort_on", "empty_output_stream", *input_args, "-map", "0:v:0",
                "-map", audio_map, "-c", "copy", "-movflags", "+faststart", str(output),
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except (OSError, subprocess.CalledProcessError) as exc:
        raise DownloadError("FFmpeg 合并 YouTube 音视频失败") from exc
    with output.open("rb") as file:
        header = file.read(12)
    if len(header) < 12 or header[4:8] != b"ftyp" or output.stat().st_size <= 12:
        raise DownloadError("FFmpeg 未生成有效的 YouTube MP4")


def download(video_id, output, ffmpeg):
    # Keep the original Go staging file untouched until the mux succeeds.
    import pytubefix

    if pytubefix.__version__ != PYTUBEFIX_VERSION:
        raise DownloadError(f"备用下载器需要 pytubefix {PYTUBEFIX_VERSION}")
    url = f"https://www.youtube.com/watch?v={video_id}"
    source = pytubefix.YouTube(
        url, client="VISION_OS", use_oauth=False, allow_oauth_cache=False, use_po_token=False
    )
    video, audio = select_streams(source.streams)
    with tempfile.TemporaryDirectory(prefix=".youtube-fallback-", dir=output.parent) as temporary:
        work_dir = Path(temporary)
        video_path = download_stream(video, work_dir, "video.mp4")
        audio_path = download_stream(audio, work_dir, "audio.m4a") if audio is not None else None
        complete = work_dir / "complete.mp4"
        merge_streams(ffmpeg, video_path, audio_path, complete)
        os.replace(complete, output)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--video-id", required=True)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--ffmpeg", required=True)
    args = parser.parse_args()
    if VIDEO_ID.fullmatch(args.video_id) is None:
        parser.error("YouTube 视频 ID 无效")
    if not args.output.is_absolute() or args.output.suffix.lower() != ".mp4":
        parser.error("输出需要绝对 MP4 路径")

    logging.disable(logging.CRITICAL)
    socket.setdefaulttimeout(NETWORK_TIMEOUT_SECONDS)
    try:
        download(args.video_id, args.output, args.ffmpeg)
    except DownloadError as exc:
        print(str(exc), file=sys.stderr)
    except ImportError:
        print("pytubefix 备用下载运行环境不可用", file=sys.stderr)
    except HTTPError as exc:
        print(f"YouTube 备用下载请求失败 (HTTP {exc.code})", file=sys.stderr)
    except (TimeoutError, URLError):
        print("YouTube 备用下载连接失败或超时", file=sys.stderr)
    except Exception as exc:
        # Upstream exception text may contain a signed media URL.
        print(f"YouTube 备用下载失败 ({type(exc).__name__})", file=sys.stderr)
    else:
        return 0
    return 1


if __name__ == "__main__":
    sys.exit(main())
